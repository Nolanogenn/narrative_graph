import narrative_lib import narrative

def test_main():
    g = narrative.new_graph()
    print(g)
